export const lightGrey = '#f2f2f2';
export const grey = '#d8d8d8';
export const black = '#222';
export const teal = '#82d8d8';
export const purp = '#524763';

export default {
  lightGrey,
  grey,
  black,
  teal,
  purp
};
